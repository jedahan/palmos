/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of preferences                                *
* Component     : Resources declaration                                       *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 07/04/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/


#define MainForm							1000
#define	MainAutoOffDuration					1010
#define	MainAutoOffDurationList				1011
#define	MainSysSoundVolume					1020
#define	MainSysSoundVolumeList				1021
#define	MainGameSoundVolume					1030
#define	MainAlarmSoundVolume				1040
#define	MainStayOnWhenPluggedIn				1050
#define	MainStayOnWhenPluggedInList			1051
#define	MainCalibrateDigitizerAtReset   	1060
#define	MainCalibrateDigitizerAtResetList	1061
#define	MainSaveSys							1090
#define	MainAppBoolean						1100
#define	MainAppBooleanList					1110
#define	MainAppNumber						1120
#define	MainAppString						1130
#define	MainSaveApp							1190

#define	MainMenu				1000
#define	MainOptionsHelpCmd		1020         
#define	MainOptionsAboutCmd		1021

#define	HelpAlert				1000
#define	AboutAlert				1001
#define	RomIncompatibleAlert	1002
#define	PrefsSavedAlert			1003
