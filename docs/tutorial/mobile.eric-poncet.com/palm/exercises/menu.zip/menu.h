/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of menu development                           *
* Component     : Resources declaration                                       *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 06/30/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/

#define MainForm		1000
#define	MainFirstName	1001
#define	MainLastName	1002
#define	MainInstrument	1003
#define	MainCursor		1004
#define	MainFirstRec	1010
#define	MainPrevRec		1011
#define	MainNextRec		1012
#define	MainLastRec		1013

#define	MainMenu				1000
#define	MainRecord1Cmd			1000
#define	MainRecord2Cmd			?
#define	MainRecord3Cmd			?
#define	MainRecord4Cmd			?
#define	MainRecord5Cmd			?
#define	MainEditClearCmd		?
#define	MainEditCutCmd			?
#define	MainEditCopyCmd			?
#define	MainEditPasteCmd		?
#define	MainEditSelectAllCmd	?
#define	MainOptionsHelpCmd		?         
#define	MainOptionsAboutCmd		?

#define	HelpAlert				1000
#define	AboutAlert				1001
#define	RomIncompatibleAlert	1002
