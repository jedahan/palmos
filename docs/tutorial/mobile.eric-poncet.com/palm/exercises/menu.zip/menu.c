/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of menu development                           *
* Component     : Main                                                        *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 06/30/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/


/* include .h */
#include <PalmTypes.h>
#include <PalmCompatibility.h>
#include <System/SystemPublic.h>
#include <UI/UIPublic.h>


#define ROM_VERSION_REQUIRED	0x02000000		// This application requires PalmOS 2.0 or later
#define	MAX_REC					5				// Nb or recs in DB


struct
{
	char	*firstName;
	char	*lastName;
	char	*instrument;
}
db[] = 
{
	{"Keith", "Jarrett"    , "Piano"},
	{"Gary" , "Peacock"    , "Bass"},
	{"Jack" , "De Johnette", "Drums"},
	{"Jacky", "Terrasson"  , "Piano"},
	{"Jaco" , "Pastorius"  , "Electric bass"}
};
UInt16	curRec = 0;


static FieldPtr SetField(UInt16 formID, UInt16 fieldID, MemPtr str)
{
	FormPtr 	frm;
	FieldPtr	fld;
	UInt16		obj;
	CharPtr		p;
	VoidHand	h;
	
	frm = FrmGetFormPtr(formID);
	obj = FrmGetObjectIndex(frm, fieldID);
	fld = (FieldPtr)FrmGetObjectPtr(frm, obj);
	h = (VoidHand)FldGetTextHandle(fld);
	if (h == NULL)
	{
		h = MemHandleNew (FldGetMaxChars(fld)+1);
		ErrFatalDisplayIf(!h, "No Memory");
	}
	
	p = (CharPtr)MemHandleLock(h);
	StrCopy(p, str);
	MemHandleUnlock(h);
	
	FldSetTextHandle(fld, (Handle)h);
}


static void SelectRecord(UInt16 id)
{
	char	cursor[20];
	
	StrPrintF(cursor, "%2d/%-2d", curRec+1, MAX_REC);
	
	SetField(MainForm, MainFirstName , db[id].firstName);		
	SetField(MainForm, MainLastName  , db[id].lastName);		
	SetField(MainForm, MainInstrument, db[id].instrument);		
	SetField(MainForm, MainCursor    , cursor);		

	FrmDrawForm(FrmGetFormPtr(MainForm));
}


static FieldPtr GetFocusObjectPtr(void)
{
	FormPtr frm;
	UInt16 focus;
	FormObjectKind objType;
	
	frm = FrmGetActiveForm();
	focus = FrmGetFocus(frm);
	if (focus == noFocus)
		return(NULL);
		
	objType = FrmGetObjectType(frm, focus);
	
	if (objType == frmFieldObj)
		return(FrmGetObjectPtr(frm, focus));
	
	else if (objType == frmTableObj)
		return(TblGetCurrentField(FrmGetObjectPtr(frm, focus)));
	
	return (NULL);
}


static Boolean MainFormHandleEvent(EventPtr event)
{
    Boolean		handled = false;
    FieldPtr	fld;

    switch (event->eType)
    {
	    case frmOpenEvent:
			if (event->data.frmOpen.formID == MainForm)
				SelectRecord(curRec);
			handled = true;
			break;
	
	    case menuEvent:
			/* menu erase */
			switch (event->data.menu.itemID)
			{
				case MainRecord1Cmd:
				case MainRecord2Cmd:
				case MainRecord3Cmd:
				case MainRecord4Cmd:
				case MainRecord5Cmd:
					SelectRecord(curRec = event->data.menu.itemID-MainRecord1Cmd);
					handled = true;
					break;
					
				case MainEditClearCmd:
					/* handler */
				    handled = true;
				    break;

				case MainEditCopyCmd:
					/* handler */
				    handled = true;
				    break;

				case MainEditCutCmd:
					/* handler */
				    handled = true;
				    break;

				case MainEditPasteCmd:
					/* handler */
				    handled = true;
				    break;

				case MainEditSelectAllCmd:
					/* handler */
				    handled = true;
				    break;

				case MainOptionsHelpCmd:
					/* handler */
				    handled = true;
				    break;
				    
				case MainOptionsAboutCmd:
					/* handler */
				    handled = true;
				    break;
				    
				default:
					break;
			}
			break;
	
	    case ctlSelectEvent:
			switch (event->data.ctlSelect.controlID)
			{
				case MainFirstRec:
					SelectRecord(curRec = 0);
				    handled = true;
				    break;

				case MainPrevRec:
					if (curRec > 0)
						SelectRecord(--curRec);
				    handled = true;
				    break;

				case MainNextRec:
					if (curRec < MAX_REC-1)
						SelectRecord(++curRec);
				    handled = true;
				    break;

				case MainLastRec:
					SelectRecord(curRec = MAX_REC-1);
				    handled = true;
				    break;

				default:
					break;
			}
			break;
	
	    case keyDownEvent:
			switch (event->data.keyDown.chr)
			{
				case vchrPageDown:
					if (curRec > 0)
						SelectRecord(--curRec);
				    handled = true;
					break;

				case vchrPageUp:
					if (curRec < MAX_REC-1)
						SelectRecord(++curRec);
				    handled = true;
				    break;

				default:
					break;
			}
			break;
	
	    case penDownEvent:
			break;
	
	    case penUpEvent:
			break;
	
	    case frmCloseEvent:
			break;
	
	    case nilEvent:
			break;
	
	    default:
			break;
    }

    return handled;
}


static Boolean AppHandleEvent(EventPtr event)
{
    FormPtr	frm;
    Int		formId;
    Boolean	handled;

    handled = false;

    if (event->eType == frmLoadEvent)
    {
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);
		switch (formId)
		{
			case MainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				handled = true;
				break;
				
			default:
				break;
		}
    }

    return handled;
}


static void AppStart()
{
	FrmGotoForm(MainForm);
}


static void AppEventLoop(void)
{
	EventType	event;
	short		error;

    do
    {
		EvtGetEvent(&event, 100);
		
		if (SysHandleEvent(&event))
			continue;
			
		/* menu handle event */

		if (AppHandleEvent(&event))
			continue;

		FrmDispatchEvent(&event);
    }
    while (event.eType != appStopEvent);
}


static void AppStop()
{
    FrmCloseAllForms();
}


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	UInt32 romVersion;

	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);	// Minimal ROM version requirement
	if (romVersion < ROM_VERSION_REQUIRED)					
	{
		FrmAlert(RomIncompatibleAlert);
		return (sysErrRomIncompatible);
	}

	if (cmd == sysAppLaunchCmdNormalLaunch)						// Normal launch
	{
		AppStart();
		AppEventLoop();
		AppStop();
	}

	return 0;
}
