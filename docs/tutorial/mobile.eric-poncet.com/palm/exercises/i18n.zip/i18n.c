/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of internationalization (I18n)                *
* Component     : Resources declaration                                       *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 07/04/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/


#include "i18n.h"
#include <PalmTypes.h>
#include <PalmCompatibility.h>
#include <System/SystemPublic.h>
#include <UI/UIPublic.h>


#define ROM_VERSION_REQUIRED	0x02000000		// This application requires PalmOS 2.0 or later


// IMPORTANT NOTE: for the clarity of this tutorial, date/time/number locale formats are defined in the resource file,
//                 so that the English/French/Spanish version of this app displays date/time/number accordingly to repective 
//                 English/French/Spanish locale, rather than system-defined preference. The latter would cause the Spanish version 
//                 of this app running on a US device to display date/time/number is US format


/* globals */

static FieldPtr SetField(UInt16 formID, UInt16 fieldID, MemPtr str)
{
	FormPtr 	frm;
	FieldPtr	fld;
	UInt16		obj;
	CharPtr		p;
	VoidHand	h;
	
	frm = FrmGetFormPtr(formID);
	obj = FrmGetObjectIndex(frm, fieldID);
	fld = (FieldPtr)FrmGetObjectPtr(frm, obj);
	h = (VoidHand)FldGetTextHandle(fld);
	if (h == NULL)
	{
		h = MemHandleNew (FldGetMaxChars(fld)+1);
		ErrFatalDisplayIf(!h, "No Memory");
	}
	
	p = (CharPtr)MemHandleLock(h);
	StrCopy(p, str);
	MemHandleUnlock(h);
	
	FldSetTextHandle(fld, (Handle)h);
}


static FieldPtr GetFocusObjectPtr(void)
{
	FormPtr frm;
	UInt16 focus;
	FormObjectKind objType;
	
	frm = FrmGetActiveForm();
	focus = FrmGetFocus(frm);
	if (focus == noFocus)
		return(NULL);
		
	objType = FrmGetObjectType(frm, focus);
	
	if (objType == frmFieldObj)
		return(FrmGetObjectPtr(frm, focus));
	
	else if (objType == frmTableObj)
		return(TblGetCurrentField(FrmGetObjectPtr(frm, focus)));
	
	return (NULL);
}


static Boolean MainFormHandleEvent(EventPtr event)
{
    Boolean		handled = false;
    FieldPtr	fld;

    switch (event->eType)
    {
	    case frmOpenEvent:
	 		{
	 			DateTimeType	dt;
				char			str[100];
				
				/* get current date and time */

				/* localize date */
				SetField(MainForm, MainDate, str);

				/* localize time */
				SetField(MainForm, MainTime, str);

				SetField(MainForm, MainNumber, "1778");

				SetField(MainForm, MainName, "Australopithecus");

				StrCopy(str, "1,234,000.00");
				SetField(MainForm, MainPopulation, /* localize number */);

				FrmDrawForm(FrmGetFormPtr(MainForm));
				handled = true;
			}
			break;
	
	    case menuEvent:
			MenuEraseStatus(NULL);
			switch (event->data.menu.itemID)
			{
				case MainEditClearCmd:
					if (fld = GetFocusObjectPtr())
						FldDelete(fld, 0, FldGetTextLength(fld));
				    handled = true;
				    break;

				case MainEditCopyCmd:
					if (fld = GetFocusObjectPtr())
						FldCopy(fld);
				    handled = true;
				    break;

				case MainEditCutCmd:
					if (fld = GetFocusObjectPtr())
						FldCut(fld);
				    handled = true;
				    break;

				case MainEditPasteCmd:
					if (fld = GetFocusObjectPtr())
						FldPaste(fld);
				    handled = true;
				    break;

				case MainEditSelectAllCmd:
					if (fld = GetFocusObjectPtr())
						FldSetSelection(fld, 0, FldGetTextLength(fld));
				    handled = true;
				    break;

				case MainOptionsAboutCmd:
				    (void)FrmAlert(AboutAlert);
				    handled = true;
				    break;
				    
				default:
					break;
			}
			break;
	
	    case ctlSelectEvent:
			switch (event->data.ctlSelect.controlID)
			{
				case MainWater:
				    handled = true;
				    break;

				case MainFeed:
				    handled = true;
				    break;

				default:
					break;
			}
			break;
	
	    case keyDownEvent:
			switch (event->data.keyDown.chr)
			{
				default:
					break;
			}
			break;
	
	    case penDownEvent:
			break;
	
	    case penUpEvent:
			break;
	
	    case frmCloseEvent:
			break;
	
	    case nilEvent:
			break;
	
	    default:
			break;
    }

    return handled;
}


static Boolean AppHandleEvent(EventPtr event)
{
    FormPtr	frm;
    Int		formId;
    Boolean	handled;

    handled = false;

    if (event->eType == frmLoadEvent)
    {
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);
		FrmDrawForm(frm);
		switch (formId)
		{
			case MainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				handled = true;
				break;
				
			default:
				break;
		}
    }

    return handled;
}


static void AppStart()
{
	MemHandle	H;

	// Get globals from localized version

	// Get date format
	H = DmGetResource(strRsc, DateFormatString);
	gDateFormat = StrAToI(MemHandleLock(H));
	MemHandleUnlock(H);
	DmReleaseResource(H);

	// Get time format
	/* time format */

	// Get thousand separator
	H = DmGetResource(strRsc, ThousandString);
	gThousand = ((char*)MemHandleLock(H))[0];
	MemHandleUnlock(H);
	DmReleaseResource(H);

	// Get decimal separator
	/* get decimal separator */
	
	FrmGotoForm(MainForm);
}


static void AppEventLoop(void)
{
	EventType	event;
	short		error;

    do
    {
		EvtGetEvent(&event, 100);
		
		if (SysHandleEvent(&event))
			continue;
			
		if (MenuHandleEvent((void *)0, &event, &error))
			continue;

		if (AppHandleEvent(&event))
			continue;

		FrmDispatchEvent(&event);
    }
    while (event.eType != appStopEvent);
}


static void AppStop()
{
    FrmCloseAllForms();
}


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	UInt32 romVersion;

	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);	// Minimal ROM version requirement
	if (romVersion < ROM_VERSION_REQUIRED)					
	{
		FrmAlert(RomIncompatibleAlert);
		return (sysErrRomIncompatible);
	}

	if (cmd == sysAppLaunchCmdNormalLaunch)						// Normal launch
	{
		AppStart();
		AppEventLoop();
		AppStop();
	}

	return 0;
}
