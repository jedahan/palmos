/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Mobile version of "Hello World"                             *
* Component     : Main                                                        *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 06/18/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/


/* add an include of hello.h here */
#include <System/SystemPublic.h>
#include <UI/UIPublic.h>


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	short err;
	/* declare a variable named "e" whose type is EventType */
	/* declare a variable named "pfrm" whose type is a pointer to a FormType */

	if (cmd == sysAppLaunchCmdNormalLaunch)			// Make sure only react to NormalLaunch, not Reset, Beam, Find, GoTo...
	{
		/* add call to GotoForm(...) here */;

	    while(1) 
		{
			/* add a call to EvtGetEvent here */
			if (SysHandleEvent(&e)) 
				continue;
			if (MenuHandleEvent((void *)0, &e, &err)) 
				continue;
	
			switch (e.eType) 
			{
					case ctlSelectEvent:
						if (e.data.ctlSelect.controlID == Ok)
							goto _quit;
						goto _default;
						break;
				
					case frmLoadEvent:
				        /* add a call to FrmSetActiveForm here */
						break;
			
					case frmOpenEvent:
						/* assign the result returned by FrmGetActiveForm() to pfrm here */
						/* call FrmDrawForm here */
						break;
		
					case menuEvent:
						break;
		
					case appStopEvent:
						goto _quit;
		
					default:
_default:
						if (FrmGetActiveForm())
							FrmHandleEvent(FrmGetActiveForm(), &e);
			}
		}

_quit:
		/* add cleanup here */
						
	}

	return 0;
}

