/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of serial communications development          *
* Component     : Resources declaration                                       *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 07/22/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/

#define MainForm					1000
/* fields ID */

#define	MainMenu					1000
#define	MainOptionsHelpCmd			1019         
#define	MainOptionsAboutCmd			1020

#define	HelpAlert					1000
#define	AboutAlert					1001
#define	RomIncompatibleAlert		1002
#define	ErrorAlert					1003
