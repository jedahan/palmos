/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of serial communications development          *
* Component     : Main                                                        *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 07/22/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/


#include "serial.h"
#include <PalmTypes.h>
#include <PalmCompatibility.h>
#include <System/SystemPublic.h>
#include <UI/UIPublic.h>


#define ROM_VERSION_REQUIRED	0x02000000		// This application requires PalmOS 2.0 or later


/* declare port */

static FieldPtr SetField(UInt16 formID, UInt16 fieldID, MemPtr str)
{
	FormPtr 	frm;
	FieldPtr	fld;
	UInt16		obj;
	CharPtr		p;
	VoidHand	h;
	
	frm = FrmGetFormPtr(formID);
	obj = FrmGetObjectIndex(frm, fieldID);
	fld = (FieldPtr)FrmGetObjectPtr(frm, obj);
	h = (VoidHand)FldGetTextHandle(fld);
	if (h == NULL)
	{
		h = MemHandleNew (FldGetMaxChars(fld)+1);
		ErrFatalDisplayIf(!h, "No Memory");
	}
	
	p = (CharPtr)MemHandleLock(h);
	StrCopy(p, str);
	MemHandleUnlock(h);
	
	FldSetTextHandle(fld, (Handle)h);
	
	return fld;
}


static Boolean MainFormHandleEvent(EventPtr event)
{
    Boolean			handled = false;
   	Err				err;
   	Char			reply[100];

    switch (event->eType)
    {
	    case frmOpenEvent:
	    {
			FrmDrawForm(FrmGetActiveForm());
			handled = true;
			break;
		}
	
	    case ctlSelectEvent:
			switch (event->data.ctlSelect.controlID)
			{
				case MainDownloadDate:
					/* flush receive port */
					/* send "DATE" command */
receiveReply:					
					if (err == 0)
					{
						char*	ptr = reply;
						/* flush send port */
						while (/* receive data */ == 1)
							if (*ptr == '\n')				// end of line
								break;						// exit loop
								else ptr++;
						*ptr = '\0';									// store end of string

						FldDrawField(SetField(MainForm, MainReply, reply));	// refresh field on UI
					}
					else ErrAlert(err);
					break;
					
				case MainDownloadTime:
					/* flush receive port */
					/* send "TIME" command */
					goto receiveReply;
					
				case MainDownloadCrap:
					SrmReceiveFlush(port, 0);
					SrmSend(port, "CRAPPY_stuff :(\n", 16, &err);
					goto receiveReply;
					
				default:
					break;
			}
			break;
	
	    default:
			break;
    }

    return handled;
}



static Boolean AppHandleEvent(EventPtr event)
{
    FormPtr	frm;
    Int		formId;
    Boolean	handled = false;

    if (event->eType == frmLoadEvent)
    {
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);
		switch (formId)
		{
			case MainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				handled = true;
				break;
				
			default:
				break;
		}
    }
	else
    if (event->eType == menuEvent)
	{
		MenuEraseStatus(NULL);
		switch (event->data.menu.itemID)
		{
			case MainOptionsHelpCmd:
			    FrmAlert(HelpAlert);
			    handled = true;
			    break;
			    
			case MainOptionsAboutCmd:
			    FrmAlert(AboutAlert);
			    handled = true;
			    break;
			    
			default:
				break;
		}
	}
	
    return handled;
}


static Err AppStart()
{
	Err		retcode = 0;

	/* open serial port, check code and fire up main form */
		
	return retcode;
}


static void AppEventLoop(void)
{
	EventType	event;
	short		error;

    do
    {
		EvtGetEvent(&event, 100);

		if (SysHandleEvent(&event))
			continue;
			
		if (MenuHandleEvent((void *)0, &event, &error))
			continue;

		if (AppHandleEvent(&event))
			continue;

		FrmDispatchEvent(&event);
    }
    while (event.eType != appStopEvent);
}


static Err AppStop()
{
	Err		retcode;
	
	/* close all forms and close port */
		
    return retcode;
}


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	UInt32		rom;

	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &rom);	// Minimal ROM version requirement
	if (rom < ROM_VERSION_REQUIRED)					
	{
		FrmAlert(RomIncompatibleAlert);
		return(sysErrRomIncompatible);
	}

	if (cmd == sysAppLaunchCmdNormalLaunch)						// Normal launch
	{
		Err retcode;

		if ((retcode = AppStart()) != 0)
		{
			ErrAlert(retcode);
			return(retcode);
		}
		AppEventLoop();
		if ((retcode = AppStop()) != 0)
		{
			ErrAlert(retcode);
			return(retcode);
		}
	}

	return 0;
}
