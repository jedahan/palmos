/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of beaming development          			  *
* Component     : Main                                                        *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 09/16/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/


/* forgot something*/

#include <PalmTypes.h>
#include <PalmCompatibility.h>
#include <System/SystemPublic.h>
#include <UI/UIPublic.h>


/* creator ID */
#define	VersionID				1
/* extension ID */
/* default file name */
#define ROM_VERSION_REQUIRED	0x02000000		// This application requires PalmOS 2.0 or later


typedef	struct	{
					UInt16	ID;
					Char	name[MainNameSize+1];
					Char	description[MainDescriptionSize+1];
					UInt32	quantity;
				}
		FakeRecordType;
typedef	FakeRecordType*	FakeRecordPtr;		


FakeRecordType	record;
/* declare socket */


static Char* GetField(UInt16 formID, UInt16 fieldID)
{
	FormPtr 			frm;
	FieldPtr			fld;
	UInt16				obj;
	
	frm = FrmGetFormPtr(formID);
	obj = FrmGetObjectIndex(frm, fieldID);
	fld = (FieldPtr)FrmGetObjectPtr(frm, obj);
	return 	FldGetTextPtr(fld);
}


static FieldPtr SetField(UInt16 formID, UInt16 fieldID, MemPtr str)
{
	FormPtr 	frm;
	FieldPtr	fld;
	UInt16		obj;
	CharPtr		p;
	VoidHand	h;
	
	frm = FrmGetFormPtr(formID);
	obj = FrmGetObjectIndex(frm, fieldID);
	fld = (FieldPtr)FrmGetObjectPtr(frm, obj);
	h = (VoidHand)FldGetTextHandle(fld);
	if (h == NULL)
	{
		h = MemHandleNew (FldGetMaxChars(fld)+1);
		ErrFatalDisplayIf(!h, "No Memory");
	}
	
	p = (CharPtr)MemHandleLock(h);
	StrCopy(p, str);
	MemHandleUnlock(h);
	
	FldSetTextHandle(fld, (Handle)h);
	
	return fld;
}


static void BeamRecord()
{
	Char	filename[sizeof(Filename)+1] = Filename;
	Err		err;
	
	// Initializing this socket structure is key to a successful beaming
	/* init socket */

	if ((err = /* call ExgPut */) == 0)
		{
			Char*	str;

			// link has been established OK, let's prepare the record to send
			if (str=GetField(MainForm, MainID))
				record.ID = StrAToI(str);
			if (str=GetField(MainForm, MainName))
				StrCopy(record.name, str);
			if (str=GetField(MainForm, MainDescription))
				StrCopy(record.description, str);
			if (str=GetField(MainForm, MainQuantity))
				record.quantity = StrAToI(str);
			
			// now, we SEND the record, yeahhhh!
			if (/* call ExgSend */)		// partial beam?
			{
				FrmCustomAlert(ErrorAlert, "Beaming error!", "Some data has NOT been beamed", "");
				SetField(MainForm, MainStatus, "Record PARTIALLY beamed");
			}
			if ((err = /* call ExgDisconnet */) == 0)		// clean up, say good bye and... check if there's any error
				SetField(MainForm, MainStatus, "Yiipee! Record beamed OK");
				else
				{
					ErrAlert(err);
					SetField(MainForm, MainStatus, "Arghhhh! Record NOT beamed!");
				}

		}
		else
		{
			ErrAlert(err);
			SetField(MainForm, MainStatus, "Unable to connect");
		}
}


static Boolean MainFormHandleEvent(EventPtr event)
{
    UInt16			recordSize = sizeof(record);
    Boolean			handled = false;

    switch (event->eType)
    {
	    case frmOpenEvent:
	    {
			if (PrefGetAppPreferences(CreatorID, 0, &record, &recordSize, true) == noPreferenceFound)
				MemSet(&record, sizeof(record), 0);
				else
				{
					Char	str[10];
					SetField(MainForm, MainID, StrIToA(str, record.ID));
					SetField(MainForm, MainName, record.name);
					SetField(MainForm, MainDescription, record.description);
					SetField(MainForm, MainQuantity, StrIToA(str, record.quantity));
				}
			FrmDrawForm(FrmGetActiveForm());
			handled = true;
			break;
		}
	
	    case ctlSelectEvent:
			switch (event->data.ctlSelect.controlID)
			{
				case MainBeamBtn:
					/* add call to BeamRecord */
					FrmDrawForm(FrmGetActiveForm());
					handled = true;
					break;
					
				case MainClearBtn:
					MemSet(&record, sizeof(record), 0);
					PrefSetAppPreferences(CreatorID, 0, VersionID, &record, sizeof(record), true);	// reset preferences as well
					SetField(MainForm, MainID, "");
					SetField(MainForm, MainName, "");
					SetField(MainForm, MainDescription, "");
					SetField(MainForm, MainQuantity, "");
					SetField(MainForm, MainStatus, "");
					FrmDrawForm(FrmGetActiveForm());
					handled = true;
					break;
					
				default:
					break;
			}
			break;
	
	    default:
			break;
    }

    return handled;
}



static Boolean AppHandleEvent(EventPtr event)
{
    FormPtr	frm;
    Int		formId;
    Boolean	handled = false;

    if (event->eType == frmLoadEvent)
    {
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);
		switch (formId)
		{
			case MainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				handled = true;
				break;
				
			default:
				break;
		}
    }
	else
    if (event->eType == menuEvent)
	{
		MenuEraseStatus(NULL);
		switch (event->data.menu.itemID)
		{
			case MainRecordBeamCmd:
				/* call BeamRecord */
				handled = true;
				break;
				
			case MainOptionsHelpCmd:
			    FrmAlert(HelpAlert);
			    handled = true;
			    break;
			    
			case MainOptionsAboutCmd:
			    FrmAlert(AboutAlert);
			    handled = true;
			    break;
			    
			default:
				break;
		}
	}
	
    return handled;
}


static Err AppStart()
{
	Err		err = 0;

	ExgRegisterData(CreatorID, exgRegExtensionID, ExtensionID);
	FrmGotoForm(MainForm);
	
	return err;
}


static void AppEventLoop(void)
{
	EventType	event;
	short		error;

    do
    {
		EvtGetEvent(&event, 100);

		if (SysHandleEvent(&event))
			continue;
			
		if (MenuHandleEvent((void *)0, &event, &error))
			continue;

		if (AppHandleEvent(&event))
			continue;

		FrmDispatchEvent(&event);
    }
    while (event.eType != appStopEvent);
}


static Err AppStop()
{
	Err		err = 0;
	
    FrmCloseAllForms();
    
    /**** err = ExgRegisterData(CreatorID, exgRegExtensionID, ""); ****/		// TRAP! let's NOT unregister, as we want this app to be the receiver for OUR fake record!
    
    return err;
}


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	UInt32		rom;
	Err			err;

	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &rom);	// Minimal ROM version requirement
	if (rom < ROM_VERSION_REQUIRED)					
	{
		FrmAlert(RomIncompatibleAlert);
		return(sysErrRomIncompatible);
	}

	if (cmd == sysAppLaunchCmdNormalLaunch)						// Normal launch
	{
		if ((err = AppStart()) != 0)
		{
			ErrAlert(err);
			return(err);
		}
		AppEventLoop();
		if ((err = AppStop()) != 0)
		{
			ErrAlert(err);
			return(err);
		}
	}
	else
	if (cmd == sysAppLaunchCmdExgAskUser)						// STEP 1: A device is initiating a beaming session
	{															// PalmOS automatically handles this by default, but we do it for fun (and for free:)
		/* ExgAskOk */
	}
	else
	if (cmd == sysAppLaunchCmdExgReceiveData)					// STEP 2: The device is sending data
	{
		/* declare pSocket and buffer */
		Err				err;							

		if ((err = /* call ExgAccept */) != 0)
		{
			ErrAlert(err);
			return(err);
		}

		if (/* call ExgReceive */ == sizeof(buffer))		// reception OK ?
		{
			PrefSetAppPreferences(CreatorID, 0, VersionID, &buffer, sizeof(buffer), true);	// save data in preferences (this is just a tutorial, so NO db!)
			pSocket->goToCreator = CreatorID;													// use same application for the GoTo launch code
			MemSet(&(pSocket->goToParams), sizeof(pSocket->goToParams), 0);						// we don't care for params, as we only have 1 rec for this tutorial
		}
		else FrmCustomAlert(ErrorAlert, "Reception error!", "Discarding data", "");

		if ((err = /* call ExgDisconnect */) != 0)			// clean up, say good bye and... check if there's any error
			ErrAlert(err);
	}
	else
	if (cmd == sysAppLaunchCmdGoTo)								// STEP 3: We'd like to display this beautiful record we just beamed in
	{
		FakeRecordType	buffer;									// we HAVE to declare a local version here to avoid fatal exception of unavailable globals :(
		UInt16			bufferSize = sizeof(buffer);
		Char			str[10], str2[10];

		if (PrefGetAppPreferences(CreatorID, 0, &buffer, &bufferSize, true) == noPreferenceFound)
			MemSet(&buffer, sizeof(buffer), 0);
		/* display data */
	}

	return 0;
}
