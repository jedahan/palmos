/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of beaming development          			  *
* Component     : Resources declaration                                       *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 09/16/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/

#define MainForm					1000
#define MainID						1001
#define	MainIDSize					4
#define MainName					1002
#define	MainNameSize				16
#define MainDescription				1003
#define	MainDescriptionSize			100
#define MainQuantity				1004
#define	MainQuantitySize			6
/* beam, clear buttons and status field */
#define	MainMenu					1000
#define	MainOptionsHelpCmd			1019         
#define	MainOptionsAboutCmd			1020
#define	MainRecordBeamCmd			1021

#define	HelpAlert					1000
#define	AboutAlert					1001
#define	RomIncompatibleAlert		1002
#define	ErrorAlert					1003
#define	ReceivedDataAlert			1004
