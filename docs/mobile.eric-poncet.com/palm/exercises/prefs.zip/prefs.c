/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of preferences                                *
* Component     : Resources declaration                                       *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 08/02/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/


#include "prefs.h"
#include <PalmTypes.h>
#include <PalmCompatibility.h>
#include <System/SystemPublic.h>
#include <UI/UIPublic.h>


/* define creatorID and versionID */
#define ROM_VERSION_REQUIRED	0x02000000		// This application requires PalmOS 2.0 or later


// Globals
UInt32	gAutoOffDuration, gSysSoundVolume, gStayOnWhenPluggedIn, gCalibrateDigitizerAtReset;
/* the struct that contains our app prefs */

static Char* GetField(UInt16 formID, UInt16 fieldID)
{
	FormPtr 	frm;
	FieldPtr	fld;
	UInt16		obj;
	
	frm = FrmGetFormPtr(formID);
	obj = FrmGetObjectIndex(frm, fieldID);
	fld = (FieldPtr)FrmGetObjectPtr(frm, obj);
	return FldGetTextPtr(fld);
}


static FieldPtr SetField(UInt16 formID, UInt16 fieldID, MemPtr str)
{
	FormPtr 	frm;
	FieldPtr	fld;
	UInt16		obj;
	CharPtr		p;
	VoidHand	h;
	
	frm = FrmGetFormPtr(formID);
	obj = FrmGetObjectIndex(frm, fieldID);
	fld = (FieldPtr)FrmGetObjectPtr(frm, obj);
	h = (VoidHand)FldGetTextHandle(fld);
	if (h == NULL)
	{
		h = MemHandleNew (FldGetMaxChars(fld)+1);
		ErrFatalDisplayIf(!h, "No Memory");
	}
	
	p = (CharPtr)MemHandleLock(h);
	StrCopy(p, str);
	MemHandleUnlock(h);
	
	FldSetTextHandle(fld, (Handle)h);
}


static Int16 GetList(UInt16 formID, UInt16 listID)
{
	FormPtr 	frm;
	ListPtr		lst;
    ControlPtr  pop;

	frm = FrmGetFormPtr(formID);
	lst = (ListPtr)FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, listID));

	return LstGetSelection(lst);
}


static FieldPtr SetList(UInt16 formID, UInt16 popupID, UInt16 listID, Int16 item)
{
	FormPtr 	frm;
	ListPtr		lst;
    ControlPtr  pop;
    Char        *txt;

	frm = FrmGetFormPtr(formID);
    pop = (ControlPtr)FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, popupID));
	lst = (ListPtr)FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, listID));

	LstSetSelection(lst, item);

    txt = LstGetSelectionText(lst, item);
    CtlSetLabel(pop, txt);
}


static Boolean MainFormHandleEvent(EventPtr event)
{
    Boolean		handled = false;
    FieldPtr	fld;

    switch (event->eType)
    {
	    case frmOpenEvent:
	 		{
				UInt	nAutoOffDuration, nSysSoundVolume;
				char	buf[20];
				
				nAutoOffDuration = ((gAutoOffDuration <= 3) ? gAutoOffDuration : 3);
				if (nAutoOffDuration > 0)
					nAutoOffDuration--;
				SetList(MainForm, MainAutoOffDuration, MainAutoOffDurationList, nAutoOffDuration);

				if (gSysSoundVolume <= 7)
					nSysSoundVolume = 0;
					else
				if (gSysSoundVolume <= 31)
					nSysSoundVolume = 1;
					else
				if (gSysSoundVolume <= 63)
					nSysSoundVolume = 2;
					else
					nSysSoundVolume = 3;
				SetList(MainForm, MainSysSoundVolume, MainSysSoundVolumeList, nSysSoundVolume);

				SetList(MainForm, MainStayOnWhenPluggedIn, MainStayOnWhenPluggedInList, (gStayOnWhenPluggedIn == 0) ? 0 : 1);

				SetList(MainForm, MainCalibrateDigitizerAtReset, MainCalibrateDigitizerAtResetList, ((gCalibrateDigitizerAtReset == 0) ? 0 : 1));

				SetList(MainForm, MainAppBoolean, MainAppBooleanList, ((gAppPrefs.b == 0) ? 0 : 1));

				StrIToA(buf, gAppPrefs.ui);
				SetField(MainForm, MainAppNumber, buf);

				SetField(MainForm, MainAppString, gAppPrefs.s);

				FrmDrawForm(FrmGetFormPtr(MainForm));
				handled = true;
			}
			break;
	
	    case menuEvent:
			MenuEraseStatus(NULL);
			switch (event->data.menu.itemID)
			{
				case MainOptionsHelpCmd:
				    (void)FrmAlert(HelpAlert);
				    handled = true;
				    break;
				    
				case MainOptionsAboutCmd:
				    (void)FrmAlert(AboutAlert);
				    handled = true;
				    break;
				    
				default:
					break;
			}
			break;
	
	    case ctlSelectEvent:
			switch (event->data.ctlSelect.controlID)
			{
				case MainSaveSys:
					{
						UInt16	nSysSoundVolume;
						Boolean	bStayOnWhenPluggedIn=true;
						Boolean	bCalibrateDigitizerAtReset=true;

						PrefSetPreference(prefAutoOffDuration, GetList(MainForm, MainAutoOffDurationList) + 1);

						switch (GetList(MainForm, MainSysSoundVolumeList))
						{
							case 0:
								nSysSoundVolume = 0;
								break;
							case 1:
								nSysSoundVolume = 8;
								break;
							case 2:
								nSysSoundVolume = 32;
								break;
							case 3:
								nSysSoundVolume = 64;
								break;
							default:
								nSysSoundVolume = gSysSoundVolume;
								break;
						}
						PrefSetPreference(prefSysSoundVolume, nSysSoundVolume);

						/* save 2 other sys prefs */

						FrmAlert(PrefsSavedAlert);

					    handled = true;
				    }
				    break;

				case MainSaveApp:
					{
						/* save app prefs */
						
						FrmAlert(PrefsSavedAlert);

					    handled = true;
				    }
				    break;

				default:
					break;
			}
			break;
	
	    case keyDownEvent:
			switch (event->data.keyDown.chr)
			{
				default:
					break;
			}
			break;
	
	    case penDownEvent:
			break;
	
	    case penUpEvent:
			break;
	
	    case frmCloseEvent:
			break;
	
	    case nilEvent:
			break;
	
	    default:
			break;
    }

    return handled;
}


static Boolean AppHandleEvent(EventPtr event)
{
    FormPtr	frm;
    Int		formId;
    Boolean	handled;

    handled = false;

    if (event->eType == frmLoadEvent)
    {
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);
		FrmDrawForm(frm);
		switch (formId)
		{
			case MainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				handled = true;
				break;
				
			default:
				break;
		}
    }

    return handled;
}


static void AppStart()
{
	UInt16	nAppPrefsSize;
	
	// Get system prefs

	// Get app prefs
	
	FrmGotoForm(MainForm);
}


static void AppEventLoop(void)
{
	EventType	event;
	short		error;

    do
    {
		EvtGetEvent(&event, 100);
		
		if (SysHandleEvent(&event))
			continue;
			
		if (MenuHandleEvent((void *)0, &event, &error))
			continue;

		if (AppHandleEvent(&event))
			continue;

		FrmDispatchEvent(&event);
    }
    while (event.eType != appStopEvent);
}


static void AppStop()
{
    FrmCloseAllForms();
}


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	UInt32 romVersion;

	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);	// Minimal ROM version requirement
	if (romVersion < ROM_VERSION_REQUIRED)					
	{
		FrmAlert(RomIncompatibleAlert);
		return (sysErrRomIncompatible);
	}

	if (cmd == sysAppLaunchCmdNormalLaunch)						// Normal launch
	{
		AppStart();
		AppEventLoop();
		AppStop();
	}

	return 0;
}
