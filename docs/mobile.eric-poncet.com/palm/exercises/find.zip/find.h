/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of find development                           *
* Component     : Resources declaration                                       *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 08/30/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/

#define MainForm			1000
#define	MainFirstName		1001
#define	MainFirstNameIndex	1
#define	MainLastName		1002
#define	MainLastNameIndex	2
#define	MainCursor			1004
#define	MainFirstRec		1010
#define	MainPrevRec			1011
#define	MainNextRec			1012
#define	MainLastRec			1013

#define	MainMenu				1000
#define	MainRecord1Cmd			1000
#define	MainRecord2Cmd			1001
#define	MainRecord3Cmd			1002
#define	MainRecord4Cmd			1003
#define	MainRecord5Cmd			1004
#define	MainOptionsHelpCmd		1020         
#define	MainOptionsAboutCmd		1021

#define	HelpAlert				1000
#define	AboutAlert				1001
#define	RomIncompatibleAlert	1002
