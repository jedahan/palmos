import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;

/**
 * <p>Basic serial server - receives a request and sends the reply
 * <p>EZ to use - just run the server on a given port, 
 * run the PRC file on your Palm device
 * <p>Run the class with "java" without any argument to get usage
 *
 * @author Eric Poncet
 * @version 1.0
 */

public class Serial
{
    private String		request, reply;
    private ServerSocket	server = null;
    private Socket		client = null;
    private PrintStream		sockOut = null;
    private DataInputStream	sockIn = null;

    private static int		port = 0;

    /**
     * Opens a socket - required before actual communication with client can be done
     * @returns nothing
     */
    private void OpenSocket()
    {
	try
	{
		server = new ServerSocket(port);
		client = server.accept();
		sockOut = new PrintStream(
				new BufferedOutputStream(
					client.getOutputStream(), 1024), false);
		sockIn = new DataInputStream(
				new BufferedInputStream(
					client.getInputStream()));
	}
	catch (IOException e)
	{
		System.err.println("IO: " + e.getMessage());
		System.exit(2);
	}
    }

    /**
     * Talks with the server through a socket - this is where actual communication with server is done
     * @returns a boolean indicating whether the user entered a request (true) or not (false)
     */
    private boolean TalkSocket()
    {
		boolean	b = true;
		String	argument;
	
		try
		{
		  	while ((request = sockIn.readLine()) != null)
		 	{
				System.out.println("Received: " + request);
		  		if (request.toLowerCase().startsWith("date"))
		  		{
		  			Date		today = new Date();
					DateFormat	dateFormatter = DateFormat.getDateInstance(DateFormat.DEFAULT, new Locale("en", "US"));
         			reply = dateFormatter.format(today);
         		}
         		else
		  		if (request.toLowerCase().startsWith("time"))
		  		{
		  			Date		today = new Date();
					DateFormat	timeFormatter = DateFormat.getTimeInstance(DateFormat.DEFAULT, new Locale("en", "US"));
         			reply = timeFormatter.format(today);
         		}
     			else reply = "Unknown command";
         		sockOut.println(reply + "\n");
         		sockOut.flush();
				System.out.println("Replied: " + reply);
	  		}
		}
		catch (IOException e)
		{
			System.out.println("IO: " + e.getMessage());
		}
		return	b;
    }

    /**
     * Closes a socket - required to end actual communication with server
     * @returns nothing
     */
    private void CloseSocket() throws IOException
    {
		sockOut.close();
		sockIn.close();
		client.close();
		server.close();
    }

    /**
     * Opens a socket - required before actual communication with server can be done
     * @param	port	port number
     */
    public static void main(String[] args) throws IOException
    {
		boolean	carryOn = true;
	
		if (args.length != 1)
		   {
			System.err.println("Usage: Serial port");
			System.err.println("port is the port number where the host listens");
			System.exit(0);
		   }
	
		port = java.lang.Integer.parseInt(args[0]);
	
		System.out.println("Welcome to Serial Server");
		System.out.println("Run Serial application on your Palm");
		System.out.println("");
	
		while (carryOn)
		{
			Serial	ser = new Serial();
	
			ser.OpenSocket();
			carryOn = ser.TalkSocket();
			ser.CloseSocket();
		}
	
		System.out.println("\nThanks for using Serial Server!");
    }
}