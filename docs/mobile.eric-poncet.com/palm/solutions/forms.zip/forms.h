#define FormFirst	1000
#define Form1 		1000
#define Form2 		1001
#define Form3 		1002
#define Form4 		1003
#define FormLast	1003

#define	Form3Minus	2044
#define	Form3Count	2045
#define	Form3Plus	2046

#define Prev	 	9000
#define Next 		9001
#define Exit 		9002

#define Table		1000
#define	TableCols	2
#define	TableRows	8

#define	Bitmap		1000
#define Alert1 		1000
#define Help1 		1000
