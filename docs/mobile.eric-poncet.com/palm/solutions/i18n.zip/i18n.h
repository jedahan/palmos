/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of internationalization (I18n)                *
* Component     : Resources declaration                                       *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 07/04/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/

#define MainForm		1000
#define	MainDate		1001
#define	MainTime		1002
#define	MainNumber		1003
#define	MainName		1004
#define	MainFamily		1005
#define	MainFamilyList	1006
#define	MainPopulation	1007
#define	MainWater		1008
#define	MainFeed		1009

#define	MainMenu				1000
#define	MainEditClearCmd		1010
#define	MainEditCutCmd			1011
#define	MainEditCopyCmd			1012
#define	MainEditPasteCmd		1013
#define	MainEditSelectAllCmd	1014
#define	MainOptionsHelpCmd		1020         
#define	MainOptionsAboutCmd		1021

#define	HelpAlert				1000
#define	AboutAlert				1001
#define	RomIncompatibleAlert	1002

#define	DateFormatString		1000
#define	TimeFormatString		1001
#define	ThousandString			1002
#define	DecimalString			1003
