/*****************************************************************************\
*                                                                             *
* Project       : Mobile development tutorial                                 *
* Application   : Demonstration of find development                           *
* Component     : Main                                                        *
* Author        : Eric Poncet (mobile.eric-poncet.com)                        *
* Creation      : 08/30/2000                                                  *
*                                                                             *
*******************************************************************************
*                                                                             *
* History       :                                                             *
*                                                                             *
\*****************************************************************************/


#include "find.h"
#include <PalmTypes.h>
#include <PalmCompatibility.h>
#include <System/SystemPublic.h>
#include <UI/UIPublic.h>


#define	CreatorID				'TuFi'
#define	VersionID				1
#define ROM_VERSION_REQUIRED	0x02000000		// This application requires PalmOS 2.0 or later
#define	MAX_REC					5				// Nb or recs in DB


typedef	struct
		{
			char	*firstName;
			char	*lastName;
		}
		VolatileRecordType;

												// This macro is a trick to easily create the db, both in the main app as a global
												// and in the search function as a local, b/c globals are NOT available
												// This is silly, but we end up creating the fake DB at every launch...
												// The purpose of this tutorial is the Find thing
												// For real DB stuff, please refer to DB tutorial
#define	CREATE_DB(storage) \
		storage VolatileRecordType db[] = \
		{ \
			{"Jim"    , "Bar"}, \
			{"Peter"  , "Baz"}, \
			{"Jim"    , "Foo"}, \
			{"John"   , "Smith"}, \
			{"Terence", "Smith"} \
		}

CREATE_DB(static);
UInt16	curRec = 0;


static FieldPtr SetField(UInt16 formID, UInt16 fieldID, MemPtr str)
{
	FormPtr 	frm;
	FieldPtr	fld;
	UInt16		obj;
	CharPtr		p;
	VoidHand	h;
	
	frm = FrmGetFormPtr(formID);
	obj = FrmGetObjectIndex(frm, fieldID);
	fld = (FieldPtr)FrmGetObjectPtr(frm, obj);
	h = (VoidHand)FldGetTextHandle(fld);
	if (h == NULL)
	{
		h = MemHandleNew (FldGetMaxChars(fld)+1);
		ErrFatalDisplayIf(!h, "No Memory");
	}
	
	p = (CharPtr)MemHandleLock(h);
	StrCopy(p, str);
	MemHandleUnlock(h);
	
	FldSetTextHandle(fld, (Handle)h);
}


static void SelectRecord(UInt16 id)
{
	char	cursor[20];
	
	StrPrintF(cursor, "%2d/%-2d", curRec+1, MAX_REC);
	
	SetField(MainForm, MainFirstName , db[id].firstName);		
	SetField(MainForm, MainLastName  , db[id].lastName);		
	SetField(MainForm, MainCursor    , cursor);		

	FrmDrawForm(FrmGetFormPtr(MainForm));
}


static Boolean MainFormHandleEvent(EventPtr event)
{
    Boolean		handled = false;
    FieldPtr	fld;

    switch (event->eType)
    {
	    case frmOpenEvent:
			if (event->data.frmOpen.formID == MainForm)
				SelectRecord(curRec);
			handled = true;
			break;
	
	    case menuEvent:
			MenuEraseStatus(NULL);
			switch (event->data.menu.itemID)
			{
				case MainRecord1Cmd:
				case MainRecord2Cmd:
				case MainRecord3Cmd:
				case MainRecord4Cmd:
				case MainRecord5Cmd:
					SelectRecord(curRec = event->data.menu.itemID-MainRecord1Cmd);
					handled = true;
					break;
					
				case MainOptionsHelpCmd:
				    (void)FrmAlert(HelpAlert);
				    handled = true;
				    break;
				    
				case MainOptionsAboutCmd:
				    (void)FrmAlert(AboutAlert);
				    handled = true;
				    break;
				    
				default:
					break;
			}
			break;
	
	    case ctlSelectEvent:
			switch (event->data.ctlSelect.controlID)
			{
				case MainFirstRec:
					SelectRecord(curRec = 0);
				    handled = true;
				    break;

				case MainPrevRec:
					if (curRec > 0)
						SelectRecord(--curRec);
				    handled = true;
				    break;

				case MainNextRec:
					if (curRec < MAX_REC-1)
						SelectRecord(++curRec);
				    handled = true;
				    break;

				case MainLastRec:
					SelectRecord(curRec = MAX_REC-1);
				    handled = true;
				    break;

				default:
					break;
			}
			break;
	
	    case keyDownEvent:
			switch (event->data.keyDown.chr)
			{
				case vchrPageDown:
					if (curRec > 0)
						SelectRecord(--curRec);
				    handled = true;
					break;

				case vchrPageUp:
					if (curRec < MAX_REC-1)
						SelectRecord(++curRec);
				    handled = true;
				    break;

				default:
					break;
			}
			break;
	
	    case penDownEvent:
			break;
	
	    case penUpEvent:
			break;
	
	    case frmCloseEvent:
			break;
	
	    case nilEvent:
			break;
	
	    default:
			break;
    }

    return handled;
}


static Boolean AppHandleEvent(EventPtr event)
{
    FormPtr	frm;
    Int		formId;
    Boolean	handled;

    handled = false;

    if (event->eType == frmLoadEvent)
    {
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);
		switch (formId)
		{
			case MainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				handled = true;
				break;
				
			default:
				break;
		}
    }

    return handled;
}


static void AppStart()
{
	UInt16	curRecSize = sizeof(curRec);
	if (PrefGetAppPreferences(CreatorID, 0, &curRec, &curRecSize, true) == noPreferenceFound)
		MemSet(&curRec, sizeof(curRec), 0);

	FrmGotoForm(MainForm);
}


static void AppEventLoop(void)
{
	EventType	event;
	short		error;

    do
    {
		EvtGetEvent(&event, 100);
		
		if (SysHandleEvent(&event))
			continue;
			
		if (MenuHandleEvent((void *)0, &event, &error))
			continue;

		if (AppHandleEvent(&event))
			continue;

		FrmDispatchEvent(&event);
    }
    while (event.eType != appStopEvent);
}


static void AppStop()
{
    FrmCloseAllForms();

	PrefSetAppPreferences(CreatorID, 0, VersionID, &curRec, sizeof(curRec), true);	// save cursor in app preferences
}


static void SaveData(SysAppLaunchCmdSaveDataType* params)
{
	// if we get interrupted b/c user launches a "Find", we'd like to save persistent data
	// here, it's pretty small, and it's just for the purpose of this tutorial
	
	PrefSetAppPreferences(CreatorID, 0, VersionID, &curRec, sizeof(curRec), true);	// save cursor in app preferences
}


static void LookFor(FindParamsPtr params)
{
	UInt16			rec = params->recordNum, fld = -1, length;
	UInt32			pos;
	Boolean			found;
	UInt16			card = 0;		// we don't have a real DB... let's improvise :)
	LocalID			dbID = 0;
	RectangleType	rect;
	CREATE_DB(auto);
		
	if (FindDrawHeader(params, "Tutorial"))		// returns true if Find screen is filled up, in which case we MUST return from this function
		return;
	
	while (true)
	{
		if (											// here, we give a chance to the user to cancel the Find
			((rec%10) == 0) &&							// every 10 records
			EvtSysEventAvail(true)						// if there's a system event to process
		   )
			{
				params->more = true;				// we confirm there are some more records to check
				break;									// see you soon :)
			}

		if (found = TxtFindString(db[rec].firstName, params->strToFind, &pos, &length))		// search first name
			fld = MainFirstNameIndex;
			else
		if (found = TxtFindString(db[rec].lastName, params->strToFind, &pos, &length))		// search last name
			fld = MainLastNameIndex;

		if (found)
		{
			if (FindSaveMatch(params, rec, pos, fld, length, card, dbID))					// no space to display result
				return;																		// bye bye

			FindGetLineBounds(params, &rect);												// where should we display match on the "Find" dialog?
			
			WinDrawTruncChars(db[rec].firstName, StrLen(db[rec].firstName), rect.topLeft.x+1, rect.topLeft.y, (rect.extent.x/2)-2);
			WinDrawTruncChars(db[rec].lastName, StrLen(db[rec].lastName), rect.topLeft.x+(rect.extent.x/2), rect.topLeft.y, (rect.extent.x/2)-2);

			params->lineNumber++;
		}
		
		if (++rec >= MAX_REC)						// next in line, please... or... maybe there's no more????
		{
			params->more = false;				// we confirm there are NO more records to check
			break;									// hasta la vista :)
		}
	}
}


static void GoTo(GoToParamsPtr params)
{
	curRec = params->recordNum;
}


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	UInt32 romVersion;

	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);	// Minimal ROM version requirement
	if (romVersion < ROM_VERSION_REQUIRED)					
	{
		FrmAlert(RomIncompatibleAlert);
		return (sysErrRomIncompatible);
	}

	switch (cmd)
	{
		case sysAppLaunchCmdNormalLaunch:		// Normal launch: we have a UI, handlers and all the stuff
			AppStart();
			AppEventLoop();
			AppStop();
			break;
			
		case sysAppLaunchCmdSaveData:			// STEP 1: let's be careful... system requests us to SAVE any pending data before terminating us and launching the global search
			if (launchFlags & sysAppLaunchFlagSubCall)			// Actually... we save ONLY if we're the active app - otherwise, there ain't nothin' to save :)
				SaveData((SysAppLaunchCmdSaveDataType*)cmdPBP);
			break;
			
		case sysAppLaunchCmdFind:				// STEP 2: here we are... system requests us to search for data that user is looking for
			LookFor((FindParamsPtr)cmdPBP);
			break;
			
		case sysAppLaunchCmdGoTo:				// STEP 3: there we go... system requests us to SHOW the data we just told him we had found!
			if (launchFlags & sysAppLaunchFlagNewGlobals)		// We're being launched... so we have more stuff to do than just display something
			{
				AppStart();
				GoTo((GoToParamsPtr)cmdPBP);
				AppEventLoop();
				AppStop();
			}
			else												// We're ALREADY running... so just display the data we found previously
			{
				GoTo((GoToParamsPtr)cmdPBP);
				SelectRecord(curRec);
			}
			break;
			
		default:
			break;
	}
		
	return 0;
}
