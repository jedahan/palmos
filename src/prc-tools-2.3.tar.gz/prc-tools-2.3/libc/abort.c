void
abort (void) {
  }
