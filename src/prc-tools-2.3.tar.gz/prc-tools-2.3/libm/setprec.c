/* Null stubs for coprocessor precision settings */

sprec() { }
dprec() { }
ldprec() { }
